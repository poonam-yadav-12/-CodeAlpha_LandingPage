$(document).ready(function() {
  // Add fade-in animation to home section
  $('#home').addClass('fade-in');
});

